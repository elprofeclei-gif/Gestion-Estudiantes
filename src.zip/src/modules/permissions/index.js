const router = require('./permission.routes');

module.exports = {
  router,
};
