const bcrypt = require('bcrypt');

const env = require('../../config/env');

const BaseService = require('../../core/base/BaseService');
const ConflictError = require('../../core/errors/ConflictError');

const userRepository = require('./UserRepository');

class UserService extends BaseService {
  constructor() {
    super(userRepository, {
      unique: ['correo'],
    });
  }

  async create(data) {
    const existe = await this.repository.findByEmail(data.correo);

    if (existe) {
      throw new ConflictError('El correo ya está registrado.');
    }

    data.password = await bcrypt.hash(data.password, env.bcrypt.rounds);

    return super.create(data);
  }

  async findById(id) {
    return super.findById(id, {
      populate: ['rol'],
    });
  }

  async findAll(filter = {}, options = {}) {
    return super.findAll(filter, {
      ...options,
      populate: ['rol'],
    });
  }
}

module.exports = new UserService();
