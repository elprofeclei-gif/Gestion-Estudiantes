const BaseRouter = require('../../core/base/BaseRouter');
const userController = require('./UserController');
const userValidator = require('./UserValidator');

module.exports = new BaseRouter(userController, userValidator).getRouter();
