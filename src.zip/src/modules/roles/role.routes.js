const BaseRouter = require('../../core/base/BaseRouter');
const roleController = require('./RoleController');
const roleValidator = require('./RoleValidator');

module.exports = new BaseRouter(roleController, roleValidator).getRouter();
