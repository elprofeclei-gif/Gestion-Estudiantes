const BaseRepository = require('../../core/database/BaseRepository');
const User = require('./User');

class UserRepository extends BaseRepository {
  constructor() {
    super(User);
  }

  async findByEmail(correo) {
    return this.findOne(
      { correo },
      {
        select: '+password',
        populate: ['rol'],
      }
    );
  }
}

module.exports = new UserRepository();
