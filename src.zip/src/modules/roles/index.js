const router = require('./role.routes');

module.exports = {
  router,
};
