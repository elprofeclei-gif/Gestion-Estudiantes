const express = require('express');

const authController = require('./AuthController');
const authValidator = require('./AuthValidator');

const router = express.Router();

router.post('/login', ...authValidator.login, authController.login);

module.exports = router;
