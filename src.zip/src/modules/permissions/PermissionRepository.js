const BaseRepository = require('../../core/database/BaseRepository');
const Permission = require('./Permission');

class PermissionRepository extends BaseRepository {
  constructor() {
    super(Permission);
  }

  async findByName(nombre) {
    return this.findOne({ nombre });
  }
}

module.exports = new PermissionRepository();
