const BaseRepository = require('../../core/database/BaseRepository');
const Role = require('./Role');

class RoleRepository extends BaseRepository {
  constructor() {
    super(Role);
  }

  async findByName(nombre) {
    return this.findOne({ nombre });
  }
}

module.exports = new RoleRepository();
