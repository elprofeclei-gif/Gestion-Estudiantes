const express = require('express');

const authRoutes = require('../modules/auth/auth.routes');
const permissionRoutes = require('../modules/permissions/permission.routes');
const roleRoutes = require('../modules/roles/role.routes');
const userRoutes = require('../modules/users/user.routes');

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/permissions', permissionRoutes);
router.use('/roles', roleRoutes);
router.use('/users', userRoutes);

module.exports = router;
