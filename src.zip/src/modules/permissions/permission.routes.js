const BaseRouter = require('../../core/base/BaseRouter');
const permissionController = require('./PermissionController');
const permissionValidator = require('./PermissionValidator');

module.exports = new BaseRouter(permissionController, permissionValidator).getRouter();
